package cn.neusoft.service.impl;

import cn.neusoft.domain.Account;
import cn.neusoft.domain.OperatorInfo;
import cn.neusoft.mapper.CaptchaMapper;
import cn.neusoft.mapper.LoginMapper;
import cn.neusoft.service.CaptchaService;
import cn.neusoft.utills.CaptchaUtill;
import cn.neusoft.vo.ResultBean;
import com.aliyun.dysmsapi20170525.models.SendSmsResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Random;
import java.util.concurrent.TimeUnit;

@Service
public class CaptchaServiceImpl implements CaptchaService {
    static final String signName = "ZSBcenter";
    static final String SMS = "SMS_461985248";
    static final String accessKeyId = "LTAI5tEJPJNikoKKbycGUJVJ";
    static final String accessKeySecret = "dj1hxsHbrmiaGICVHNwLTcP5SH9T0i";

    @Autowired
    CaptchaMapper captchaMapper;
    @Autowired
    LoginMapper loginMapper;
    @Autowired
    RedisTemplate redisTemplate;

    //登录/修改密码：发送验证码
    @Override
    public ResultBean sendCaptcha(String phoneNumber){
        //首先检索数据库里该手机号是否已经被注册
        Account result = captchaMapper.findByPhone(phoneNumber);
        if(result == null){
            return ResultBean.fail(400,"该手机号尚未注册,请重新确认手机号");
        }
        //验证通过，可以发送验证码
        //生成一个6位随机数作为验证码，放在Session里
        int rand = new Random().nextInt(1000000);
        String verifyCode = String.format("%06d", rand);
        System.out.println("验证码：" + verifyCode);
//        {"code":"1234"}
        String verifyCode2 = "{\"code\":\"" + verifyCode + "\"}";
        System.out.println("更改后的验证码：" + verifyCode);
        //构建代理，调用send方法，发送验证码
        SendSmsResponse sendSmsResponse = null;
        try {
            sendSmsResponse = CaptchaUtill.send(accessKeyId,accessKeySecret,SMS,phoneNumber,signName,verifyCode2);
        } catch (Exception e) {
            e.printStackTrace();
            return ResultBean.fail(400,"服务器内部错误，当前无法发送验证码");
        }
        //获取发送验证码的结果
        System.out.println(sendSmsResponse);
        //检查验证码是否发送成功
        if(!sendSmsResponse.getBody().getCode().equals("OK")){
            return ResultBean.fail(400,sendSmsResponse.getBody().getMessage());
        }
        //成功发送验证码,保存本次的手机号与验证码
        //因为redis存入时会自动覆盖先前的value，所以无需判断手机号之前是否已经有该手机号的键值对
        redisTemplate.opsForValue().set(phoneNumber,verifyCode);
        // 使用redisTemplate操作控件的expire时间为2分钟
        redisTemplate.expire(phoneNumber, 2, TimeUnit.MINUTES);
        System.out.println(redisTemplate.opsForValue().get(phoneNumber));
        return ResultBean.fail(200,"已成功发送验证码，2分钟有效，请查收");
    }
    //注册：发送验证码
    @Override
    public ResultBean sendCaptchaReg(String phoneNumber,String account){
        //首先进行账号的验证，是否有重复
        //检查是否有输入的账号
        System.out.println("检查账号");
        Integer account_examine = loginMapper.findByAccount(account);
        if (account_examine != null){
            return ResultBean.fail(400,"您输入的账号已被注册");
        }
        //首先检索数据库里该手机号是否已经被注册
        Account result = captchaMapper.findByPhone(phoneNumber);
        if(result != null){
            return ResultBean.fail(400,"该手机号已被注册");
        }
        //验证通过，可以发送验证码
        //生成一个6位随机数作为验证码，放在Session里
        int rand = new Random().nextInt(1000000);
        String verifyCode = String.format("%06d", rand);
        String verifyCode2 = "{\"code\":\"" + verifyCode + "\"}";
        //构建代理，调用send方法，发送验证码
        SendSmsResponse sendSmsResponse = null;
        try {
            sendSmsResponse = CaptchaUtill.send(accessKeyId,accessKeySecret,SMS,phoneNumber,signName,verifyCode2);
        } catch (Exception e) {
            e.printStackTrace();
            return ResultBean.fail(400,"服务器内部错误，当前无法发送验证码");
        }
        //获取发送验证码的结果
        System.out.println(sendSmsResponse);
        //检查验证码是否发送成功
        if(!sendSmsResponse.getBody().getCode().equals("OK")){
            return ResultBean.fail(400,sendSmsResponse.getBody().getMessage());
        }
        //成功发送验证码,保存本次的手机号与验证码
        //因为redis存入时会自动覆盖先前的value，所以无需判断手机号之前是否已经有该手机号的键值对
        redisTemplate.opsForValue().set(phoneNumber,verifyCode);
        // 使用redisTemplate操作控件的expire时间为2分钟
        redisTemplate.expire(phoneNumber, 2, TimeUnit.MINUTES);
        System.out.println("redis中储存验证码" + redisTemplate.opsForValue().get(phoneNumber));
        return ResultBean.fail(200,"已成功发送验证码，2分钟有效，请查收");
    }
    //登录：判别验证码
    @Override
    public ResultBean examineCaptchaLogin(String phoneNumber,String captcha){
        //对传入的整个手机号码和验证码做验证
        //首先判断是否存在该手机号的键值对
        if(!redisTemplate.hasKey(phoneNumber)){
            //不存在，说明输入的手机号有误
            return ResultBean.fail(400,"请重新输入手机号");
        } else {
            //获取redis中保存的验证码
            String verifyCode = (String) redisTemplate.opsForValue().get(phoneNumber);
            System.out.println("前端验证码:" + captcha);
            System.out.println("保存的验证码:" + verifyCode);
            if(verifyCode.equals(captcha)){
                //手机号与验证码成功匹配，移除redis当中的键值对
                redisTemplate.delete(phoneNumber);
//                map.remove(phoneNumber);
                //进行下一步操作，登录
                Account account = captchaMapper.findByPhone(phoneNumber);
                return ResultBean.success("登录成功",account);
            }
            return ResultBean.fail(400,"验证码错误");
        }
    }
    //修改密码：判别验证码
    @Override
    public ResultBean examineCaptchaLookfor(Account account,String captcha){
        //对传入的整个手机号码和验证码做验证
        //首先判断是否存在该手机号的键值对
        if(!redisTemplate.hasKey(account.getPhoneNumber())){
            return ResultBean.fail(400,"请重新输入手机号获取验证码");
        }else {
            //获取redis中保存的验证码
            String verifyCode = (String) redisTemplate.opsForValue().get(account.getPhoneNumber());
            if(verifyCode.equals(captcha)){
                //手机号与验证码成功匹配，移除redis当中的键值对
                redisTemplate.delete(account.getPhoneNumber());
                //进行下一步操作，修改密码
                Integer result = captchaMapper.changePsd(account);
                if(result == null){
                    return ResultBean.fail(400,"密码修改失败，请重新尝试");
                }
                return ResultBean.success("密码修改成功，请重新登录");
            }
            return ResultBean.fail(400,"验证码错误");
        }
    }
    //注册账号：判别验证码
    public ResultBean examineCaptchaReg(Account account,String captcha){
        //首先进行账号的验证，是否有重复
        //检查是否有输入的账号
        System.out.println("检查账号");
        Integer account_examine = loginMapper.findByAccount(account.getAccount());
        if (account_examine != null){
            return ResultBean.fail(400,"您输入的账号已被注册");
        }

        //对传入的整个手机号码和验证码做验证
        //首先判断是否存在该手机号的键值对
        if(!redisTemplate.hasKey(account.getPhoneNumber())){
            return ResultBean.fail(400,"请重新输入手机号");
        }else {
            //获取redis中保存的验证码
            String verifyCode = (String) redisTemplate.opsForValue().get(account.getPhoneNumber());
            if(verifyCode.equals(captcha)){
                //手机号与验证码成功匹配，移除redis当中的键值对
                System.out.println("匹配成功，删除redis");
                redisTemplate.delete(account.getPhoneNumber());
                //进行下一步操作，注册账号
                Integer result = captchaMapper.register(account);
                if(result != null){
                    //根据角色，如果是客服，那么将新注册的账号在客服表里添加一份
                    if(account.getRole() == "客服"){
                        OperatorInfo operatorInfo = new OperatorInfo();
                        operatorInfo.setOp_income(0);
                        operatorInfo.setOp_id(account.getAccount());
                        operatorInfo.setOp_name("操作员" + account.getAccount());
                        operatorInfo.setOp_tele(account.getPhoneNumber());
                        Integer addResult = captchaMapper.addKefu(operatorInfo);
                        System.out.println("新增客服操作员信息的结果是：" + addResult);
                    }
                    return ResultBean.success("验证码通过，已注册成功");
                }
                return ResultBean.fail(400,"注册失败，请重新注册");
            }
            return ResultBean.fail(400,"验证码错误");
        }
    }
}
