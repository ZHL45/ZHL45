package cn.neusoft.utils;

import lombok.Data;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

/**
 * * 订单编码生成器，生成23位数字编码，
 * * @生成规则 1位单号类型+14位时间戳+8位(用户id加密&随机数)
 */
@Data
public class OrderUtils {
    /**
     * 订单类别头
     */

    private static final String ORDER_CODE = "O";
    /**
     * 退货类别头
     */

    private static final String RETURN_ORDER = "R";
    /**
     * 换货类别头
     */

    private static final String EXCHANGE_ORDER = "E";


    /**
     * 随即编码
     */

    private static final int[] r = new int[]{7, 9, 6, 2, 8, 1, 3, 0, 5, 4};
    /**
     * 用户id和随机数总长度
     */

    private static final int maxLength = 4;

    /**
     * 根据id进行加密+加随机数组成固定长度编码
     */
    private static String toCode(Integer userId) {
        String idStr = userId.toString();
        StringBuilder idsbs = new StringBuilder();
        for (int i = idStr.length() - 1; i >= 0; i--) {
            idsbs.append(r[idStr.charAt(i) - '0']);
        }
        return idsbs.append(getRandom(maxLength - idStr.length())).toString();
    }

    /**
     * 生成时间戳
     */
    private static String getDateTime() {
        DateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        return sdf.format(new Date());
    }

    /**
     * 生成固定长度随机码
     *
     * @param n 长度
     */

    public static long getRandom(long n) {
        long min = 1, max = 9;
        for (int i = 1; i < n; i++) {
            min *= 10;
            max *= 10;
        }
        long rangeLong = (((long) (new Random().nextDouble() * (max - min)))) + min;
        return rangeLong;
    }


    /**
     * 生成不带类别标头的编码
     *
     * @param userId
     */
//    private static synchronized String getCode(Integer userId) {
//        userId = userId == null ? 10000 : userId;
//        return getDateTime() + toCode(userId);
//    }

    //修改后的：符号1位 + 客户id8位 + 时间14位  = 23位
    /**
     * 生成正常订单单号编码(调用方法)
     * @param userId  网站中该用户唯一ID 防止重复
     */

    public static String getOrderCode(Integer userId) {
        return ORDER_CODE + userId + getDateTime();
    }


    /**
     * 生成退货单号编码（调用方法）
     * @param userId 网站中该用户唯一ID 防止重复
     */
    public static String getReturnCode(Integer userId) {
        return RETURN_ORDER + userId +  getDateTime();
    }


    /**
     * 生成退款单号编码(调用方法)
     * @param userId  网站中该用户唯一ID 防止重复
     */
    public static String getExchangeCode(Integer userId) {
        return EXCHANGE_ORDER + userId +  getDateTime();
    }

//    /**
//     * 生成正常订单单号编码(调用方法)
//     * @param userId  网站中该用户唯一ID 防止重复
//     */
//
//    public static String getOrderCode(Integer userId) {
//        return ORDER_CODE + getCode(userId);
//    }
//
//
//    /**
//     * 生成退货单号编码（调用方法）
//     * @param userId 网站中该用户唯一ID 防止重复
//     */
//    public static String getReturnCode(Integer userId) {
//        return RETURN_ORDER + getCode(userId);
//    }
//
//
//    /**
//     * 生成退款单号编码(调用方法)
//     * @param userId  网站中该用户唯一ID 防止重复
//     */
//    public static String getExchangeCode(Integer userId) {
//        return EXCHANGE_ORDER + getCode(userId);
//    }
}
